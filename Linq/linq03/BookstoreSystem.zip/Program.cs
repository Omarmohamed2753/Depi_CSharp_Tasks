using System;
using BookstoreSystem.Contexts;

namespace BookstoreSystem
{
    class Program
    {
        static void Main(string[] args)
        {
            using BookstoreDbContext db = new BookstoreDbContext();

            Console.WriteLine("Database Ready");
        }
    }
}
