using System;
using System.ComponentModel.DataAnnotations;

namespace BookstoreSystem.Models
{
    // Q1: EF Core automatically treats Id as a Primary Key by convention.
    // Q2: Country is nullable because it is declared as nullable, while Price is non-nullable.

    public class Book
    {
        public int Id { get; set; }

        public string Title { get; set; }

        public decimal Price { get; set; }

        public DateTime? PublishedDate { get; set; }
    }
}
