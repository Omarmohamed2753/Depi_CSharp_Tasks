
using System;
using System.Collections.Generic;

class Category
{
    public int Id { get; set; }
    public string Name { get; set; }
    public List<Product> Products { get; set; }
}

class Product
{
    public int Id { get; set; }
    public string Name { get; set; }
    public decimal Price { get; set; }

    public int CategoryId { get; set; }
    public Category Category { get; set; }

    public List<OrderDetail> OrderDetails { get; set; }
}

class Customer
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Email { get; set; }

    public List<Order> Orders { get; set; }
}

class Order
{
    public int Id { get; set; }
    public DateTime OrderDate { get; set; }

    public int CustomerId { get; set; }
    public Customer Customer { get; set; }

    public List<OrderDetail> OrderDetails { get; set; }
}

class OrderDetail
{
    public int OrderId { get; set; }
    public Order Order { get; set; }

    public int ProductId { get; set; }
    public Product Product { get; set; }

    public int Quantity { get; set; }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("E-Commerce System");
    }
}
