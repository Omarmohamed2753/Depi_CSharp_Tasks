
using System;
using System.Collections.Generic;

class Patient
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateTime DateOfBirth { get; set; }

    public List<Appointment> Appointments { get; set; }
}

class Doctor
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Specialization { get; set; }

    public List<Appointment> Appointments { get; set; }
}

class Appointment
{
    public int PatientId { get; set; }
    public Patient Patient { get; set; }

    public int DoctorId { get; set; }
    public Doctor Doctor { get; set; }

    public DateTime AppointmentDate { get; set; }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Health Care System");
    }
}
