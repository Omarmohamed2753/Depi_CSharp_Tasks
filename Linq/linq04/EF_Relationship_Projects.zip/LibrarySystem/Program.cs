
using System;
using System.Collections.Generic;

class Author
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateTime BirthDate { get; set; }

    public List<Book> Books { get; set; }
}

class Book
{
    public int Id { get; set; }
    public string Title { get; set; }
    public string ISBN { get; set; }

    public int AuthorId { get; set; }
    public Author Author { get; set; }

    public List<Loan> Loans { get; set; }
}

class Borrower
{
    public int Id { get; set; }
    public string Name { get; set; }
    public DateTime MembershipDate { get; set; }

    public List<Loan> Loans { get; set; }
}

class Loan
{
    public int BookId { get; set; }
    public Book Book { get; set; }

    public int BorrowerId { get; set; }
    public Borrower Borrower { get; set; }

    public DateTime LoanDate { get; set; }
    public DateTime? ReturnDate { get; set; }
}

class Program
{
    static void Main(string[] args)
    {
        Console.WriteLine("Library System");
    }
}
